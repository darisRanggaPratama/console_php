# DataTables Server-side Processing in PHP & MySql

- Import db_kontak.sql
- Ubah koneksi.php sesuaikan dengan host,username,password, dan db anda

### Preview

![preview](https://raw.githubusercontent.com/rizalrizal/php-datatable-serverside/master/preview.png "preview")