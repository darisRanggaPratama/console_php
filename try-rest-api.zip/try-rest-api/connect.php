<?php
define('HOST', 'localhost');
define('USER', 'hyvoycom_rangga');
define('PASSWORD', '20061988rangga');
define('DATABASE', 'hyvoycom_avengers');

$connects = mysqli_connect(HOST, USER, PASSWORD, DATABASE) or die('UNABLE CONNECTING');


?>
